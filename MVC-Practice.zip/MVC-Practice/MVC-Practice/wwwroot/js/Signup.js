﻿$(document).ready(function () {
    $('.signupbtn').click(function () {

        var data = {
            username: $('#UserId').val(),
            psw: $('#passId').val()
        };

        $.ajax({
            url: '/User/Signup',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function (response) {
                if (response.success) {
                    var cred = {
                        username: data.username,
                        psw: data.psw
                    }
                    let getArr = [];
                    getArr = JSON.parse(localStorage.getItem("getArr"));
                    if (getArr == null) {
                        getArr = []
                        getArr.push(cred)
                        localStorage.setItem("getArr", JSON.stringify(getArr));
                    }
                    else {
                        let log = false
                        $(getArr).each(function (i, user) {
                            if (user.username == data.username && user.psw == data.psw) {
                                log = true;
                                return false;
                            }
                        })
                        if (!log) {
                            getArr.push(cred)
                            localStorage.setItem("getArr", JSON.stringify(getArr));
                            Swal.fire({
                                title: response.message,
                                text: data.username + " has been registered successfully!",
                                type: "success",
                                showCancelButton: true,
                                confirmButtonText: "To login"
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = '/User/Login';
                                }
                            });
                        }
                        else {
                            Swal.fire({
                                title: 'User already exists',
                                text: 'Enter a new username',
                                type: 'error'

                            })
                        }
                        
                    }
                }
                else {
                    Swal.fire({
                        title: response.message,
                        text: 'Enter valid data',
                        icon: 'error'
                    })
                }

            },
            error: function (xhr, status, error) {
                Swal.fire({
                    title: 'Error!',
                    text: 'Error: ' + status + ' ' + error,
                    icon: 'error'
                })
            }
        });
    });
});
