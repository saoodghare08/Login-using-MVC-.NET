﻿$(document).ready(function () {
    $('.loginbtn').click(function () {

        var data = {
            username: $('#username').val(),
            psw: $('#psw').val()
        };

        let getArr = JSON.parse(localStorage.getItem("getArr")) || [];

        let log = false
        $(getArr).each(function (i, user) {
            if (user.username == data.username && user.psw == data.psw) {
                log = true;
                return false;
            }
        })
        if (log) {
            Swal.fire({
                title: 'Login Successfull',
                text: data.username + " has been Logged in successfully!",
                type: "success",
                confirmButtonText: "To Dashboard"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/User/Dashboard';
                }
            });
        } else {
            Swal.fire({
                title: 'Invalid credentials',
                text: 'Check your Username or Password',
                type: 'error'
            })
        }

    })
})