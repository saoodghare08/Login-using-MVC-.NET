﻿using Microsoft.AspNetCore.Mvc;
using MVC_Practice.Models;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace MVC_Practice.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }
        
        public IActionResult Dashboard()
        {
            return View();
        }

        //GET: Signup
        public IActionResult Signup()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Signup([FromBody] UserModel user)
        {
            if (user == null)
            {
                return Json(new { success = false, message = "No data received" });
            }

            if (string.IsNullOrEmpty(user.Username) || string.IsNullOrEmpty(user.psw))
            {
                return Json(new { success = false, message = "Username and password are required." });
            }

            string username = user.Username;
            string password = user.psw;

            // Return a success response
            return Json(new {data = user, success = true, message = "Signup successful!" });
        }

        //[HttpPost]
        //public IActionResult Login([FromBody] UserModel user)
        //{
        //    if (user == null)
        //    {
        //        return Json(new { success = false, message = "No data received" });
        //    }

        //    if (string.IsNullOrEmpty(user.Username) || string.IsNullOrEmpty(user.psw))
        //    {
        //        return Json(new { success = false, message = "Username and password are required." });
        //    }
        //    if (string.Equals(user.Username, )
        //    {
                
        //    }

        //    string username = user.Username;
        //    string password = user.psw;

        //    // Return a success response
        //    return Json(new { data = user, success = true, message = "Login successful!" });

        //}

    }
}
